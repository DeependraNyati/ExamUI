import React from 'react';
import {View, Text} from 'react-native';
const People = () => {
  return <Text>People</Text>;
};

export default People;
