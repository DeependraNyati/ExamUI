import React from 'react';
import {View, Text} from 'react-native';
const Notifications = () => {
  return <Text>Notifications</Text>;
};

export default Notifications;
