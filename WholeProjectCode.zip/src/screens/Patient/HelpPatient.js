import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

const HelpPatient = () => {
  return (
    <View style={{flex: 1}}>
      <Text>Help Patient</Text>
    </View>
  );
};

export default HelpPatient;
