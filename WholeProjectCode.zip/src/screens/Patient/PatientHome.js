import React from 'react';

import {Text, View, StyleSheet} from 'react-native';

const PatientHome = () => {
  return (
    <View style={{flex: 1}}>
      <Text>Welcome to Patient Home</Text>
    </View>
  );
};

export default PatientHome;
