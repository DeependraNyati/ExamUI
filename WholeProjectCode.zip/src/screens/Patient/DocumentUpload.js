import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

const DocumentUpload = ({navigation}) => {
  return (
    <View style={{flex: 1}}>
      <Text>Document Upload</Text>
    </View>
  );
};

export default DocumentUpload;
