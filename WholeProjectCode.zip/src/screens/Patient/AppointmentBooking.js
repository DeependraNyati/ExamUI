import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

const AppointmentBooking = () => {
  return (
    <View style={{flex: 1}}>
      <Text>AppointmentBooking</Text>
    </View>
  );
};

export default AppointmentBooking;
