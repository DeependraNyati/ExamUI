import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

const SpecialistDetail = () => {
  return (
    <View style={{flex: 1}}>
      <Text>I am Deependra</Text>
      <Text>I am D-Pain</Text>
    </View>
  );
};

export default SpecialistDetail;
