import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

const PatientHelp = () => {
  return (
    <View style={{flex: 1}}>
      <Text>Help the Patient</Text>
    </View>
  );
};

export default PatientHelp;
