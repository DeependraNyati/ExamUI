import React from 'react';
import {View, Text} from 'react-native';
const Chat = () => {
  return <Text>Chat</Text>;
};

export default Chat;
