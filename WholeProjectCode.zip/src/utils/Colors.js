export const BLUE = '#0000CD';
export const WHITE = '#fff';

export const RED = '#ff0000';
export const STEP_BACKGROUND_COLOR = '#0096FF';

export const TASK_SCREEN_BACKGROUND = '#B4CFEA';
export const TASK_REVIEW_SCREEN_BACKGROUND = '#1916A5';
export const A_DIFFERENT_BLUE = '#4D56B9';
export const AQUA = '#00FFFF';

export const BLACK = '#000000';
export const TIME_COLOR = '#003B73';

export const SKY_BLUE = '#87CEEB';
export const LIGHT_BLUE = '#ADD8E6';
